
# Dialog data
The following files contains train/dev/test split obtained from the
publicly available train and dev set of doc2dial v0.9 dataset.
/doc2dial.github.io/blob/master/file/doc2dial_v0.9.zip

doc2dial_dial_train.json
doc2dial_dial_dev.json
doc2dial_dial_test.json


# QA data obtained from the above dialog data
To obtain QA data, we use the agent turns with dialogue act of
response_only, where the answers are from leaf nodes
of the document tree structure. The following files contain the
dialogue IDs concatenated with the turn ids, which uniquely defines
the QAs we used in D2DStruct experiments.

doc2dial_dial_train.json.leaf_answer.agent.response_only
doc2dial_dial_dev.json.leaf_answer.agent.response_only
doc2dial_dial_test.json.leaf_answer.agent.response_only
